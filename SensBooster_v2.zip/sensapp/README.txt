════════════════════════════════════════
  SENS BOOSTER — HƯỚNG DẪN BUILD APK
════════════════════════════════════════

YÊU CẦU:
  Android Studio Hedgehog (2023.1.1) trở lên
  JDK 17 trở lên
  Android SDK 34

BƯỚC BUILD:
  1. Giải nén ZIP → mở thư mục "sensapp" trong Android Studio
  2. Chờ Gradle sync tự động
  3. Menu: Build → Build Bundle(s)/APK(s) → Build APK(s)
  4. APK tại: app/build/outputs/apk/debug/app-debug.apk

HOẶC TERMINAL:
  cd sensapp
  ./gradlew assembleDebug
  (Windows: gradlew.bat assembleDebug)

════════════════════════════════════════
  TÍNH NĂNG
════════════════════════════════════════

  ✓ Xin quyền Shizuku — bấm card để mở Shizuku Manager
  ✓ Xin quyền quản lý tất cả tệp
  ✓ Danh sách app user tự load, sắp xếp A-Z
  ✓ Thanh kéo nhạy 1–1000 với label (Thấp/TB/Cao)
  ✓ Con trỏ trượt 10x — nhân tốc độ hiện tại lên 10
  ✓ Khôi phục — về đúng giá trị trước khi chỉnh
  ✓ START — mở app + áp nhạy cùng lúc
  ✓ Haptic feedback khi bấm nút
  ✓ SharedPreferences lưu state giữa các lần mở
  ✓ Root shell + Shizuku fallback tự động
  ✓ Áp nhạy qua: pointer_speed + sysfs Qualcomm/MTK
  ✓ Foreground Service để duy trì sau khi minimize

════════════════════════════════════════
  CẤU TRÚC FILE
════════════════════════════════════════

  app/src/main/
  ├── AndroidManifest.xml
  ├── java/com/sens/booster/
  │   ├── MainActivity.java      ← logic chính
  │   └── SensService.java       ← foreground service
  └── res/
      ├── layout/activity_main.xml
      ├── values/
      │   ├── themes.xml
      │   ├── colors.xml
      │   ├── strings.xml
      │   └── dimens.xml
      └── drawable/
          ├── card_bg.xml
          ├── card_border_purple.xml
          ├── card_border_cyan.xml
          ├── btn_start.xml
          ├── btn_restore.xml
          └── seek_thumb.xml
