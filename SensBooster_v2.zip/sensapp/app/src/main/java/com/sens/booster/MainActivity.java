package com.sens.booster;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_FILES = 101;
    private static final String PREFS = "sensbooster";

    private TextView tvShizukuStatus, tvFilesStatus, tvSensValue, tvSensLabel, tvLog;
    private SeekBar seekSensitivity;
    private Spinner spinnerApp;
    private LinearLayout cardShizuku, cardFiles, btnStart, btnCursor10x, btnRestore;

    private final List<AppEntry> apps = new ArrayList<>();
    private int savedOriginalPointer = 0;
    private int savedOriginalTouch  = 500;
    private SharedPreferences prefs;
    private Vibrator vibrator;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs    = getSharedPreferences(PREFS, MODE_PRIVATE);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        bindViews();
        loadApps();
        checkPermissions();
        restoreSavedState();
        wireListeners();
    }

    // ─── VIEW BINDING ────────────────────────────────────────────────────────
    private void bindViews() {
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus);
        tvFilesStatus   = findViewById(R.id.tvFilesStatus);
        tvSensValue     = findViewById(R.id.tvSensValue);
        tvSensLabel     = findViewById(R.id.tvSensLabel);
        tvLog           = findViewById(R.id.tvLog);
        seekSensitivity = findViewById(R.id.seekSensitivity);
        spinnerApp      = findViewById(R.id.spinnerApp);
        cardShizuku     = findViewById(R.id.cardShizuku);
        cardFiles       = findViewById(R.id.cardFiles);
        btnStart        = findViewById(R.id.btnStart);
        btnCursor10x    = findViewById(R.id.btnCursor10x);
        btnRestore      = findViewById(R.id.btnRestore);
    }

    // ─── LOAD INSTALLED APPS ─────────────────────────────────────────────────
    @SuppressLint("QueryPermissionsNeeded")
    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> raw = pm.getInstalledApplications(0);

        apps.clear();
        apps.add(new AppEntry("", "— Chọn ứng dụng —"));

        List<AppEntry> user = new ArrayList<>();
        for (ApplicationInfo a : raw) {
            boolean isSystem = (a.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            if (!isSystem) {
                String label = pm.getApplicationLabel(a).toString();
                user.add(new AppEntry(a.packageName, label));
            }
        }
        Collections.sort(user, (x, y) -> x.label.compareToIgnoreCase(y.label));
        apps.addAll(user);

        List<String> labels = new ArrayList<>();
        for (AppEntry e : apps) labels.add(e.label);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerApp.setAdapter(adapter);
    }

    // ─── PERMISSIONS ────────────────────────────────────────────────────────
    private void checkPermissions() {
        // MANAGE_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setGranted(tvFilesStatus);
            }
        } else {
            setGranted(tvFilesStatus);
        }

        // Shizuku — try ping via binder
        if (isShizukuRunning()) {
            setGranted(tvShizukuStatus);
        }
    }

    private boolean isShizukuRunning() {
        try {
            String out = execShell("id");
            return out != null && !out.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    // ─── RESTORE STATE ───────────────────────────────────────────────────────
    private void restoreSavedState() {
        int lastSens = prefs.getInt("last_sens", 500);
        seekSensitivity.setProgress(lastSens - 1);
        tvSensValue.setText(String.valueOf(lastSens));
        updateSensLabel(lastSens);

        savedOriginalPointer = prefs.getInt("orig_pointer", 0);
        savedOriginalTouch   = prefs.getInt("orig_touch", 500);
    }

    // ─── LISTENERS ──────────────────────────────────────────────────────────
    private void wireListeners() {

        // Shizuku card tap
        cardShizuku.setOnClickListener(v -> {
            vibrate(30);
            openShizuku();
        });

        // Files card tap
        cardFiles.setOnClickListener(v -> {
            vibrate(30);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivityForResult(i, REQ_FILES);
                } catch (Exception ex) {
                    startActivityForResult(
                            new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQ_FILES);
                }
                log("⬤  Đang mở cài đặt quyền tệp...");
            }
        });

        // SeekBar
        seekSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v = progress + 1;
                tvSensValue.setText(String.valueOf(v));
                updateSensLabel(v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {
                prefs.edit().putInt("last_sens", sb.getProgress() + 1).apply();
            }
        });

        // Con trỏ trượt 10x
        btnCursor10x.setOnClickListener(v -> {
            vibrate(60);
            savedOriginalPointer = getCurrentPointerSpeed();
            savedOriginalTouch   = seekSensitivity.getProgress() + 1;
            prefs.edit()
                    .putInt("orig_pointer", savedOriginalPointer)
                    .putInt("orig_touch", savedOriginalTouch)
                    .apply();

            int speed10x = Math.min(savedOriginalPointer + 7, 7);
            applyPointerSpeed(speed10x);
            applyTouchSensitivity(Math.min((seekSensitivity.getProgress() + 1) * 10, 1000));
            log("✓  Con trỏ trượt 10x đã áp dụng");
            Toast.makeText(this, "Con trỏ trượt 10x ✓", Toast.LENGTH_SHORT).show();
        });

        // Khôi phục
        btnRestore.setOnClickListener(v -> {
            vibrate(60);
            applyPointerSpeed(savedOriginalPointer);
            applyTouchSensitivity(savedOriginalTouch);
            log("✓  Đã khôi phục về ban đầu");
            Toast.makeText(this, "Khôi phục ✓", Toast.LENGTH_SHORT).show();
        });

        // START
        btnStart.setOnClickListener(v -> {
            vibrate(80);
            int idx = spinnerApp.getSelectedItemPosition();
            if (idx == 0) {
                Toast.makeText(this, "Chọn ứng dụng trước", Toast.LENGTH_SHORT).show();
                return;
            }

            AppEntry selected = apps.get(idx);
            int sens = seekSensitivity.getProgress() + 1;

            // Save originals
            savedOriginalPointer = getCurrentPointerSpeed();
            savedOriginalTouch   = 500;
            prefs.edit()
                    .putInt("orig_pointer", savedOriginalPointer)
                    .putInt("orig_touch", savedOriginalTouch)
                    .apply();

            // Apply
            int mapped = mapToPointerSpeed(sens);
            applyPointerSpeed(mapped);
            applyTouchSensitivity(sens);

            // Launch
            Intent launch = getPackageManager().getLaunchIntentForPackage(selected.pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launch);
                log("✓  Khởi động " + selected.label + " | nhạy " + sens);
            } else {
                log("✗  Không mở được " + selected.label);
                Toast.makeText(this, "Không mở được app", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─── SENSITIVITY LOGIC ───────────────────────────────────────────────────

    /** Map 1–1000 → Android pointer_speed -7..7 */
    private int mapToPointerSpeed(int value) {
        return (int) Math.round((value - 1) * 14.0 / 999.0) - 7;
    }

    private int getCurrentPointerSpeed() {
        try {
            return Settings.System.getInt(getContentResolver(), "pointer_speed", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    private void applyPointerSpeed(int speed) {
        // Try Settings.System (requires WRITE_SETTINGS)
        try {
            Settings.System.putInt(getContentResolver(), "pointer_speed", speed);
        } catch (Exception ignored) {}

        // Root/Shizuku fallback
        execRootSilent("settings put system pointer_speed " + speed);
        // Also try input subsystem
        execRootSilent("input touchscreen sensitivity " + ((speed + 7) * 71)); // 0-994
    }

    private void applyTouchSensitivity(int value) {
        // Standard settings key
        execRootSilent("settings put system touch_sensitivity " + value);

        // Qualcomm path
        int qVal = value * 255 / 1000;
        execRootSilent("echo " + qVal +
                " > /sys/devices/virtual/touchscreen/touchscreen_dev/sensitivity 2>/dev/null");

        // MediaTek path
        execRootSilent("echo " + value + " > /proc/touchpanel/sensitivity 2>/dev/null");

        // Generic Android input device scaling (sysfs)
        execRootSilent("echo " + value + " > /sys/bus/i2c/drivers/ft5x06/sensitivity 2>/dev/null");

        // Via wm density-based scaling (indirect)
        // pointer_speed covers most cases; device-specific paths above cover the rest
    }

    // ─── SHELL HELPERS ───────────────────────────────────────────────────────

    private String execShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            InputStream is = p.getInputStream();
            byte[] buf = new byte[256];
            int len = is.read(buf);
            return len > 0 ? new String(buf, 0, len).trim() : "";
        } catch (Exception e) {
            return null;
        }
    }

    private void execRootSilent(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.writeBytes(cmd + "\n");
            os.writeBytes("exit\n");
            os.flush();
            p.waitFor();
        } catch (Exception e) {
            // Shizuku fallback
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                p.waitFor();
            } catch (Exception ignored) {}
        }
    }

    // ─── UI HELPERS ──────────────────────────────────────────────────────────

    private void openShizuku() {
        try {
            Intent i = new Intent();
            i.setClassName("moe.shizuku.privileged.api", "moe.shizuku.manager.MainActivity");
            startActivity(i);
        } catch (Exception e1) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://shizuku.dev"));
                startActivity(i);
            } catch (Exception e2) {
                Toast.makeText(this, "Tải Shizuku tại shizuku.dev", Toast.LENGTH_LONG).show();
            }
        }
        log("⬤  Đang mở Shizuku...");
    }

    private void updateSensLabel(int v) {
        String label;
        if (v <= 200)       label = "Rất thấp";
        else if (v <= 400)  label = "Thấp";
        else if (v <= 600)  label = "Trung bình";
        else if (v <= 800)  label = "Cao";
        else                label = "Rất cao";
        tvSensLabel.setText(label);
    }

    private void setGranted(TextView tv) {
        tv.setText("✓ Đã cấp");
        tv.setTextColor(0xFF00E5BB);
    }

    private void log(String msg) {
        runOnUiThread(() -> tvLog.setText(msg));
    }

    private void vibrate(int ms) {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(ms);
        }
    }

    // ─── ACTIVITY RESULTS ────────────────────────────────────────────────────

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    && Environment.isExternalStorageManager()) {
                setGranted(tvFilesStatus);
                log("✓  Quyền tệp đã được cấp");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    // ─── DATA CLASS ──────────────────────────────────────────────────────────

    static class AppEntry {
        String pkg, label;
        AppEntry(String p, String l) { pkg = p; label = l; }
    }
}
